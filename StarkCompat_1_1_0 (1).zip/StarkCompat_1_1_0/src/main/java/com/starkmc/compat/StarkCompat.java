package com.starkmc.compat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitTask;

public final class StarkCompat extends JavaPlugin implements Listener {
    private static final long COMBAT_MILLIS = 15000L;
    private static final int BAR_LENGTH = 15;
    private static final String[] BLOCKED_COMMANDS = new String[]{"spawn", "home", "tpa", "tpaccept", "warp", "back"};
    private static final Component COMBAT_ENDED = Component.text("Combat ended", NamedTextColor.GREEN);
    private final Map<UUID, Long> combatExpiry = new HashMap<>();
    private final Map<UUID, UUID> opponents = new HashMap<>();
    private final Map<UUID, ActionBarState> lastActionBars = new HashMap<>();
    private BukkitTask timerTask;
    private CombatZones combatZones;

    @Override
    public void onEnable() {
        this.saveDefaultConfig();
        this.getServer().getPluginManager().registerEvents(this, this);

        this.combatZones = new CombatZones(this);
        this.combatZones.enable();
        this.getServer().getPluginManager().registerEvents(this.combatZones, this);
        if (this.getCommand("combatzone") != null) {
            this.getCommand("combatzone").setExecutor(this.combatZones);
            this.getCommand("combatzone").setTabCompleter(this.combatZones);
        }

        this.timerTask = Bukkit.getScheduler().runTaskTimer(this, this::tickCombat, 5L, 5L);
        this.getLogger().info("Stark.Compat enabled. Combat time: 15 seconds.");
    }

    @Override
    public void onDisable() {
        if (this.timerTask != null) {
            this.timerTask.cancel();
        }
        if (this.combatZones != null) {
            this.combatZones.disable();
        }
        this.combatExpiry.clear();
        this.opponents.clear();
        this.lastActionBars.clear();
    }

    boolean isInCombat(Player player) {
        return this.inCombat(player);
    }

    private boolean inCombat(Player player) {
        Long expiry = this.combatExpiry.get(player.getUniqueId());
        return expiry != null && expiry > System.currentTimeMillis();
    }

    private void startCombat(Player player) {
        if (player == null || !player.isOnline() || player.isDead()) {
            return;
        }
        this.combatExpiry.put(player.getUniqueId(), System.currentTimeMillis() + COMBAT_MILLIS);
        this.moveElytraOutOfArmor(player);
    }

    private void startCombat(Player player, Player opponent) {
        this.startCombat(player);
        if (opponent != null && !opponent.getUniqueId().equals(player.getUniqueId())) {
            this.opponents.put(player.getUniqueId(), opponent.getUniqueId());
        }
    }

    private void endCombat(Player player) {
        UUID playerId = player.getUniqueId();
        this.combatExpiry.remove(playerId);
        this.opponents.remove(playerId);
        this.lastActionBars.remove(playerId);
    }

    /** Read-only view of the UUIDs currently tracked as in combat. */
    Set<UUID> combatPlayers() {
        return Collections.unmodifiableSet(this.combatExpiry.keySet());
    }

    private void tickCombat() {
        if (this.combatExpiry.isEmpty()) {
            return;
        }
        long now = System.currentTimeMillis();
        // Only players that are actually in combat are visited (never the whole online list).
        for (UUID playerId : new ArrayList<>(this.combatExpiry.keySet())) {
            Long expiry = this.combatExpiry.get(playerId);
            Player player = Bukkit.getPlayer(playerId);
            if (expiry == null) {
                continue;
            }
            if (player == null || !player.isOnline()) {
                this.combatExpiry.remove(playerId);
                this.opponents.remove(playerId);
                this.lastActionBars.remove(playerId);
                continue;
            }
            this.moveElytraOutOfArmor(player);
            long remainingMillis = expiry - now;
            if (remainingMillis <= 0L || player.isDead()) {
                this.endCombat(player);
                player.sendActionBar(COMBAT_ENDED);
                continue;
            }
            int seconds = (int) ((remainingMillis + 999L) / 1000L);
            UUID opponentId = this.opponents.get(playerId);
            Player opponent = opponentId == null ? null : Bukkit.getPlayer(opponentId);
            UUID visibleOpponentId = opponent != null && opponent.isOnline() ? opponentId : null;
            ActionBarState previous = this.lastActionBars.get(playerId);
            if (previous != null && previous.seconds() == seconds
                    && Objects.equals(previous.opponentId(), visibleOpponentId)) {
                continue;
            }
            player.sendActionBar(this.buildCombatBar(opponent, seconds));
            this.lastActionBars.put(playerId, new ActionBarState(seconds, visibleOpponentId));
        }
    }

    private Component buildCombatBar(Player opponent, int seconds) {
        Component prefix = opponent != null && opponent.isOnline()
                ? Component.text(opponent.getName(), NamedTextColor.RED).append(Component.text(" Combat", NamedTextColor.RED))
                : Component.text("Combat", NamedTextColor.RED);
        int filled = Math.max(0, Math.min(BAR_LENGTH, seconds));
        String activeSegments = "\u25a0".repeat(filled);
        String inactiveSegments = "\u25a0".repeat(BAR_LENGTH - filled);
        return prefix
                .append(Component.text(" | ", NamedTextColor.GRAY))
                .append(Component.text(activeSegments, NamedTextColor.RED))
                .append(Component.text(inactiveSegments, NamedTextColor.DARK_GRAY))
                .append(Component.text(" " + seconds + "s", NamedTextColor.RED));
    }

    private void moveElytraOutOfArmor(Player player) {
        PlayerInventory inventory = player.getInventory();
        ItemStack chestplate = inventory.getChestplate();
        if (chestplate == null || chestplate.getType() != Material.ELYTRA) {
            return;
        }
        ItemStack elytra = chestplate.clone();
        int chestplateSlot = -1;
        for (int slot = 0; slot < 36; ++slot) {
            if (!this.isChestplate(inventory.getItem(slot))) {
                continue;
            }
            chestplateSlot = slot;
        }
        ItemStack replacementChestplate = chestplateSlot >= 0 ? inventory.getItem(chestplateSlot).clone() : null;
        inventory.setChestplate(null);
        if (chestplateSlot >= 0) {
            inventory.setItem(chestplateSlot, null);
            inventory.setChestplate(replacementChestplate);
        }
        HashMap<Integer, ItemStack> leftovers = inventory.addItem(elytra);
        World world = player.getWorld();
        for (ItemStack leftover : leftovers.values()) {
            world.dropItemNaturally(player.getLocation(), leftover);
        }
        player.updateInventory();
    }

    private boolean isChestplate(ItemStack item) {
        if (item == null) {
            return false;
        }
        return switch (item.getType()) {
            case LEATHER_CHESTPLATE, CHAINMAIL_CHESTPLATE, IRON_CHESTPLATE, GOLDEN_CHESTPLATE,
                 DIAMOND_CHESTPLATE, NETHERITE_CHESTPLATE -> true;
            default -> false;
        };
    }

    private boolean isElytra(ItemStack item) {
        return item != null && item.getType() == Material.ELYTRA;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerDamage(EntityDamageByEntityEvent event) {
        Entity entity = event.getEntity();
        if (!(entity instanceof Player victim)) {
            return;
        }
        Player attacker = this.resolvePlayerAttacker(event.getDamager());
        if (attacker != null && !attacker.getUniqueId().equals(victim.getUniqueId())) {
            this.startCombat(attacker, victim);
            this.startCombat(victim, attacker);
        }
    }

    private Player resolvePlayerAttacker(Entity entity) {
        if (entity instanceof Player player) {
            return player;
        }
        if (entity instanceof Projectile projectile) {
            ProjectileSource source = projectile.getShooter();
            if (source instanceof Player player) {
                return player;
            }
        }
        return null;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onExplosionDamage(EntityDamageEvent event) {
        Entity entity = event.getEntity();
        if (!(entity instanceof Player player)) {
            return;
        }
        EntityDamageEvent.DamageCause cause = event.getCause();
        if (cause == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION
                || cause == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION) {
            this.startCombat(player);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        HumanEntity humanEntity = event.getWhoClicked();
        if (!(humanEntity instanceof Player player) || !this.inCombat(player)) {
            return;
        }
        ItemStack cursor = event.getCursor();
        ItemStack current = event.getCurrentItem();
        boolean clickingArmorSlot = event.getSlotType() == InventoryType.SlotType.ARMOR;
        boolean shiftMovingElytra = event.isShiftClick() && this.isElytra(current);
        boolean placingElytraOnArmor = clickingArmorSlot && this.isElytra(cursor);
        boolean hotkeyElytraOnArmor = clickingArmorSlot
                && event.getClick() == ClickType.NUMBER_KEY
                && event.getHotbarButton() >= 0
                && this.isElytra(player.getInventory().getItem(event.getHotbarButton()));
        boolean rightClickAutoEquip = event.getClick().isRightClick()
                && this.isElytra(current)
                && (cursor == null || cursor.getType() == Material.AIR)
                && (event.getAction() == InventoryAction.PICKUP_HALF || event.getAction() == InventoryAction.PICKUP_ALL);
        if (shiftMovingElytra || placingElytraOnArmor || hotkeyElytraOnArmor || rightClickAutoEquip) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "You cannot equip Elytra while in combat!");
            player.updateInventory();
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        HumanEntity humanEntity = event.getWhoClicked();
        if (!(humanEntity instanceof Player player) || !this.inCombat(player) || !this.isElytra(event.getOldCursor())) {
            return;
        }
        for (int rawSlot : event.getRawSlots()) {
            if (event.getView().getSlotType(rawSlot) != InventoryType.SlotType.ARMOR) {
                continue;
            }
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "You cannot equip Elytra while in combat!");
            return;
        }
    }

    @EventHandler
    public void onToggleGlide(EntityToggleGlideEvent event) {
        Entity entity = event.getEntity();
        if (entity instanceof Player player) {
            if (event.isGliding() && this.inCombat(player)) {
                event.setCancelled(true);
                player.sendMessage(ChatColor.RED + "You cannot use Elytra while in combat!");
            }
        }
    }

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (!this.inCombat(player)) {
            return;
        }
        String message = event.getMessage().trim().toLowerCase(Locale.ROOT);
        if (!message.startsWith("/")) {
            return;
        }
        String root = message.substring(1).split("\\s+", 2)[0];
        int namespaceSeparator = root.indexOf(':');
        if (namespaceSeparator >= 0) {
            root = root.substring(namespaceSeparator + 1);
        }
        for (String blocked : BLOCKED_COMMANDS) {
            if (!root.equals(blocked)) {
                continue;
            }
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "You cannot use escape commands during combat!");
            return;
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        this.endCombat(victim);
        if (killer != null) {
            this.startCombat(killer);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        if (this.inCombat(player)) {
            Location location = player.getLocation();
            PlayerInventory inventory = player.getInventory();
            for (int slot = 0; slot < 36; ++slot) {
                ItemStack item = inventory.getItem(slot);
                if (item == null || item.getType() == Material.AIR) {
                    continue;
                }
                player.getWorld().dropItemNaturally(location, item.clone());
                inventory.setItem(slot, null);
            }
            ItemStack[] armor = new ItemStack[]{inventory.getHelmet(), inventory.getChestplate(),
                    inventory.getLeggings(), inventory.getBoots()};
            for (ItemStack item : armor) {
                if (item == null || item.getType() == Material.AIR) {
                    continue;
                }
                player.getWorld().dropItemNaturally(location, item.clone());
            }
            inventory.setHelmet(null);
            inventory.setChestplate(null);
            inventory.setLeggings(null);
            inventory.setBoots(null);
            UUID opponentId = this.opponents.get(playerId);
            Player opponent = opponentId == null ? null : Bukkit.getPlayer(opponentId);
            if (opponent != null) {
                opponent.sendMessage(ChatColor.RED + "[CombatLog] " + ChatColor.YELLOW + player.getName()
                        + ChatColor.RED + " logged out during combat!");
            }
        }
        for (Map.Entry<UUID, UUID> entry : this.opponents.entrySet()) {
            if (!playerId.equals(entry.getValue())) {
                continue;
            }
            this.lastActionBars.remove(entry.getKey());
        }
        this.combatExpiry.remove(playerId);
        this.opponents.remove(playerId);
        this.lastActionBars.remove(playerId);
    }

    private record ActionBarState(int seconds, UUID opponentId) {
    }
}
