package com.starkmc.compat;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.scheduler.BukkitTask;

/**
 * Combat-blocked zones. Combat-tagged players see a red client-side wall on the
 * zone border, cannot enter the zone and cannot break/place on the wall.
 * Completely silent for players (no messages).
 */
public final class CombatZones implements Listener, TabExecutor {

    private static final Pattern NAME_PATTERN = Pattern.compile("[A-Za-z0-9_-]{1,32}");

    private record BlockPos(int x, int y, int z) {
    }

    private static final class Zone {
        final String name;
        final String world;
        final int minX;
        final int minY;
        final int minZ;
        final int maxX;
        final int maxY;
        final int maxZ;

        Zone(String name, String world, int x1, int y1, int z1, int x2, int y2, int z2) {
            this.name = name;
            this.world = world;
            this.minX = Math.min(x1, x2);
            this.minY = Math.min(y1, y2);
            this.minZ = Math.min(z1, z2);
            this.maxX = Math.max(x1, x2);
            this.maxY = Math.max(y1, y2);
            this.maxZ = Math.max(z1, z2);
        }

        boolean contains(String worldName, int x, int y, int z) {
            return this.world.equals(worldName)
                    && x >= this.minX && x <= this.maxX
                    && y >= this.minY && y <= this.maxY
                    && z >= this.minZ && z <= this.maxZ;
        }
    }

    private static final class Shown {
        final World world;
        final Set<BlockPos> cells = new HashSet<>();
        int lastX = Integer.MIN_VALUE;
        int lastY = Integer.MIN_VALUE;
        int lastZ = Integer.MIN_VALUE;
        int lastVersion = -1;
        int lastTick = Integer.MIN_VALUE;

        Shown(World world) {
            this.world = world;
        }
    }

    private final StarkCompat plugin;
    private final File zonesFile;
    private final Map<String, Zone> zones = new LinkedHashMap<>();
    private final Map<UUID, Shown> shown = new HashMap<>();
    private final Map<UUID, Location> pos1 = new HashMap<>();
    private final Map<UUID, Location> pos2 = new HashMap<>();
    private BlockData wallData = Bukkit.createBlockData(Material.RED_STAINED_GLASS);
    private int radius = 8;
    private int refreshTicks = 2;
    private int zonesVersion = 0;
    private BukkitTask task;

    public CombatZones(StarkCompat plugin) {
        this.plugin = plugin;
        this.zonesFile = new File(plugin.getDataFolder(), "zones.yml");
    }

    // ------------------------------------------------------------------ lifecycle

    public void enable() {
        this.load();
        this.startTask();
    }

    public void disable() {
        if (this.task != null) {
            this.task.cancel();
            this.task = null;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.clear(player);
        }
        this.shown.clear();
    }

    public void reload() {
        if (this.task != null) {
            this.task.cancel();
            this.task = null;
        }
        this.plugin.reloadConfig();
        this.load();
        this.startTask();
    }

    private void startTask() {
        this.task = Bukkit.getScheduler().runTaskTimer(this.plugin, this::tick, 1L, this.refreshTicks);
    }

    private void load() {
        this.plugin.reloadConfig();
        String materialName = this.plugin.getConfig().getString("zones.wall-material", "RED_STAINED_GLASS");
        Material material = Material.matchMaterial(materialName == null ? "" : materialName);
        if (material == null || !material.isBlock()) {
            material = Material.RED_STAINED_GLASS;
        }
        this.wallData = Bukkit.createBlockData(material);
        this.radius = Math.max(2, Math.min(24, this.plugin.getConfig().getInt("zones.view-radius", 8)));
        this.refreshTicks = Math.max(1, Math.min(20, this.plugin.getConfig().getInt("zones.refresh-ticks", 2)));

        this.zones.clear();
        this.zonesVersion++;
        if (!this.zonesFile.exists()) {
            this.plugin.saveResource("zones.yml", false);
        }
        if (!this.zonesFile.exists()) {
            return;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(this.zonesFile);
        ConfigurationSection section = yaml.getConfigurationSection("zones");
        if (section == null) {
            return;
        }
        for (String name : section.getKeys(false)) {
            ConfigurationSection zs = section.getConfigurationSection(name);
            if (zs == null) {
                continue;
            }
            String world = zs.getString("world");
            if (world == null) {
                continue;
            }
            int[] v;
            if (zs.contains("minX")) {
                v = new int[]{zs.getInt("minX"), zs.getInt("minY"), zs.getInt("minZ"),
                        zs.getInt("maxX"), zs.getInt("maxY"), zs.getInt("maxZ")};
            } else {
                List<Integer> min = zs.getIntegerList("min");
                List<Integer> max = zs.getIntegerList("max");
                if (min.size() != 3 || max.size() != 3) {
                    continue;
                }
                v = new int[]{min.get(0), min.get(1), min.get(2), max.get(0), max.get(1), max.get(2)};
            }
            this.zones.put(name.toLowerCase(Locale.ROOT), new Zone(name, world, v[0], v[1], v[2], v[3], v[4], v[5]));
        }
    }

    private void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (Zone zone : this.zones.values()) {
            String key = "zones." + zone.name;
            yaml.set(key + ".world", zone.world);
            yaml.set(key + ".minX", zone.minX);
            yaml.set(key + ".minY", zone.minY);
            yaml.set(key + ".minZ", zone.minZ);
            yaml.set(key + ".maxX", zone.maxX);
            yaml.set(key + ".maxY", zone.maxY);
            yaml.set(key + ".maxZ", zone.maxZ);
        }
        try {
            if (!this.plugin.getDataFolder().exists()) {
                this.plugin.getDataFolder().mkdirs();
            }
            yaml.save(this.zonesFile);
        } catch (IOException e) {
            this.plugin.getLogger().warning("Could not save zones.yml: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ wall rendering

    private void tick() {
        if (this.zones.isEmpty()) {
            if (!this.shown.isEmpty()) {
                for (UUID id : new ArrayList<>(this.shown.keySet())) {
                    Player p = Bukkit.getPlayer(id);
                    if (p != null) {
                        this.clear(p);
                    }
                }
                this.shown.clear();
            }
            return;
        }
        // Remove walls from players whose combat ended
        if (!this.shown.isEmpty()) {
            for (UUID id : new ArrayList<>(this.shown.keySet())) {
                Player p = Bukkit.getPlayer(id);
                if (p == null) {
                    this.shown.remove(id);
                } else if (!this.plugin.isInCombat(p)) {
                    this.clear(p);
                }
            }
        }
        // Update only players that are in combat (never the whole online list)
        for (UUID id : this.plugin.combatPlayers()) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && p.isOnline() && this.plugin.isInCombat(p)) {
                this.update(p);
            }
        }
    }

    private void update(Player player) {
        World world = player.getWorld();
        Location loc = player.getLocation();
        int px = loc.getBlockX();
        int py = loc.getBlockY();
        int pz = loc.getBlockZ();

        UUID id = player.getUniqueId();
        Shown cached = this.shown.get(id);
        int nowTick = Bukkit.getCurrentTick();
        if (cached != null && cached.world.equals(world) && cached.lastX == px && cached.lastY == py
                && cached.lastZ == pz && cached.lastVersion == this.zonesVersion && nowTick - cached.lastTick < 20) {
            return; // nothing changed: skip all work
        }

        Set<BlockPos> wanted = new HashSet<>();
        for (Zone zone : this.zones.values()) {
            if (!zone.world.equals(world.getName())) {
                continue;
            }
            if (zone.contains(zone.world, px, py, pz)) {
                continue; // player is inside: no wall, free to leave
            }
            if (px < zone.minX - this.radius || px > zone.maxX + this.radius
                    || py < zone.minY - this.radius || py > zone.maxY + this.radius
                    || pz < zone.minZ - this.radius || pz > zone.maxZ + this.radius) {
                continue;
            }
            this.collectShell(zone, world, px, py, pz, wanted);
        }

        Shown state = this.shown.get(id);
        if (state != null && !state.world.equals(world)) {
            this.shown.remove(id);
            state = null;
        }
        if (state == null) {
            if (wanted.isEmpty()) {
                return;
            }
            state = new Shown(world);
            this.shown.put(id, state);
        }

        Iterator<BlockPos> it = state.cells.iterator();
        while (it.hasNext()) {
            BlockPos pos = it.next();
            if (!wanted.contains(pos)) {
                this.restore(player, world, pos);
                it.remove();
            }
        }
        for (BlockPos pos : wanted) {
            if (state.cells.add(pos)) {
                player.sendBlockChange(new Location(world, pos.x(), pos.y(), pos.z()), this.wallData);
            }
        }
        if (state.cells.isEmpty()) {
            this.shown.remove(id);
            return;
        }
        state.lastX = px;
        state.lastY = py;
        state.lastZ = pz;
        state.lastVersion = this.zonesVersion;
        state.lastTick = nowTick;
    }

    /** Collects the outer-shell blocks of the zone that are within view radius of the player. */
    private void collectShell(Zone zone, World world, int px, int py, int pz, Set<BlockPos> out) {
        int x0 = Math.max(zone.minX, px - this.radius);
        int x1 = Math.min(zone.maxX, px + this.radius);
        int y0 = Math.max(Math.max(zone.minY, py - this.radius), world.getMinHeight());
        int y1 = Math.min(Math.min(zone.maxY, py + this.radius), world.getMaxHeight() - 1);
        int z0 = Math.max(zone.minZ, pz - this.radius);
        int z1 = Math.min(zone.maxZ, pz + this.radius);
        if (x0 > x1 || y0 > y1 || z0 > z1) {
            return;
        }
        for (int x = x0; x <= x1; x++) {
            boolean xEdge = x == zone.minX || x == zone.maxX;
            for (int y = y0; y <= y1; y++) {
                if (xEdge || y == zone.minY || y == zone.maxY) {
                    for (int z = z0; z <= z1; z++) {
                        this.addCell(world, x, y, z, out);
                    }
                } else {
                    if (zone.minZ >= z0 && zone.minZ <= z1) {
                        this.addCell(world, x, y, zone.minZ, out);
                    }
                    if (zone.maxZ != zone.minZ && zone.maxZ >= z0 && zone.maxZ <= z1) {
                        this.addCell(world, x, y, zone.maxZ, out);
                    }
                }
            }
        }
    }

    private void addCell(World world, int x, int y, int z, Set<BlockPos> out) {
        if (!world.isChunkLoaded(x >> 4, z >> 4)) {
            return;
        }
        if (world.getBlockAt(x, y, z).getType().isSolid()) {
            return; // real solid blocks already block movement; don't hide them
        }
        out.add(new BlockPos(x, y, z));
    }

    private void restore(Player player, World world, BlockPos pos) {
        if (!world.isChunkLoaded(pos.x() >> 4, pos.z() >> 4)) {
            return;
        }
        player.sendBlockChange(new Location(world, pos.x(), pos.y(), pos.z()),
                world.getBlockAt(pos.x(), pos.y(), pos.z()).getBlockData());
    }

    private void clear(Player player) {
        Shown state = this.shown.remove(player.getUniqueId());
        if (state == null) {
            return;
        }
        World world = player.getWorld();
        if (!state.world.equals(world)) {
            return;
        }
        for (BlockPos pos : state.cells) {
            this.restore(player, world, pos);
        }
    }

    private boolean isWall(Player player, Block block) {
        Shown state = this.shown.get(player.getUniqueId());
        return state != null
                && state.world.equals(block.getWorld())
                && state.cells.contains(new BlockPos(block.getX(), block.getY(), block.getZ()));
    }

    /** Re-sends the fake block next tick so the client's break/place prediction is undone. */
    private void protect(Player player, Block block) {
        final World world = block.getWorld();
        final BlockPos pos = new BlockPos(block.getX(), block.getY(), block.getZ());
        Bukkit.getScheduler().runTask(this.plugin, () -> {
            if (!player.isOnline()) {
                return;
            }
            Shown state = this.shown.get(player.getUniqueId());
            if (state != null && state.world.equals(world) && state.cells.contains(pos)) {
                player.sendBlockChange(new Location(world, pos.x(), pos.y(), pos.z()), this.wallData);
            }
        });
    }

    // ------------------------------------------------------------------ entry blocking

    private boolean entersZone(Location from, Location to) {
        if (from.getWorld() == null || to.getWorld() == null) {
            return false;
        }
        String fromWorld = from.getWorld().getName();
        String toWorld = to.getWorld().getName();
        for (Zone zone : this.zones.values()) {
            boolean toInside = zone.contains(toWorld, to.getBlockX(), to.getBlockY(), to.getBlockZ());
            if (!toInside) {
                continue;
            }
            boolean fromInside = zone.contains(fromWorld, from.getBlockX(), from.getBlockY(), from.getBlockZ());
            if (!fromInside) {
                return true;
            }
        }
        return false;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (this.zones.isEmpty()) {
            return;
        }
        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null) {
            return;
        }
        if (from.getBlockX() == to.getBlockX() && from.getBlockY() == to.getBlockY()
                && from.getBlockZ() == to.getBlockZ()) {
            return;
        }
        Player player = event.getPlayer();
        if (!this.plugin.isInCombat(player)) {
            return;
        }
        if (this.entersZone(from, to)) {
            Location back = from.clone();
            back.setYaw(to.getYaw());
            back.setPitch(to.getPitch());
            event.setTo(back);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        if (this.zones.isEmpty()) {
            return;
        }
        PlayerTeleportEvent.TeleportCause cause = event.getCause();
        if (cause != PlayerTeleportEvent.TeleportCause.ENDER_PEARL
                && cause != PlayerTeleportEvent.TeleportCause.CHORUS_FRUIT) {
            return;
        }
        Player player = event.getPlayer();
        if (this.plugin.isInCombat(player) && event.getTo() != null && this.entersZone(event.getFrom(), event.getTo())) {
            event.setCancelled(true);
        }
    }

    // ------------------------------------------------------------------ wall protection

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBreak(BlockBreakEvent event) {
        if (this.isWall(event.getPlayer(), event.getBlock())) {
            event.setCancelled(true);
            this.protect(event.getPlayer(), event.getBlock());
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamage(BlockDamageEvent event) {
        if (this.isWall(event.getPlayer(), event.getBlock())) {
            event.setCancelled(true);
            this.protect(event.getPlayer(), event.getBlock());
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlace(BlockPlaceEvent event) {
        if (this.isWall(event.getPlayer(), event.getBlockPlaced())) {
            event.setCancelled(true);
            this.protect(event.getPlayer(), event.getBlockPlaced());
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteract(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.LEFT_CLICK_BLOCK && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        Block clicked = event.getClickedBlock();
        if (clicked != null && this.isWall(event.getPlayer(), clicked)) {
            event.setCancelled(true);
            this.protect(event.getPlayer(), clicked);
        }
    }

    // ------------------------------------------------------------------ cleanup

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        this.shown.remove(id);
        this.pos1.remove(id);
        this.pos2.remove(id);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        this.shown.remove(event.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------------ command

    private void msg(CommandSender sender, String text, NamedTextColor color) {
        sender.sendMessage(Component.text(text, color));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("starkcompat.admin")) {
            this.msg(sender, "You do not have permission.", NamedTextColor.RED);
            return true;
        }
        if (args.length == 0) {
            this.msg(sender, "Usage: /" + label + " <pos1|pos2|create|remove|list|reload>", NamedTextColor.YELLOW);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "pos1", "pos2" -> {
                if (!(sender instanceof Player player)) {
                    this.msg(sender, "Players only.", NamedTextColor.RED);
                    return true;
                }
                Location block = player.getLocation().getBlock().getLocation();
                if (sub.equals("pos1")) {
                    this.pos1.put(player.getUniqueId(), block);
                } else {
                    this.pos2.put(player.getUniqueId(), block);
                }
                this.msg(sender, sub + " set to " + block.getBlockX() + ", " + block.getBlockY() + ", "
                        + block.getBlockZ(), NamedTextColor.GREEN);
            }
            case "create" -> {
                if (!(sender instanceof Player player)) {
                    this.msg(sender, "Players only.", NamedTextColor.RED);
                    return true;
                }
                if (args.length < 2 || !NAME_PATTERN.matcher(args[1]).matches()) {
                    this.msg(sender, "Usage: /" + label + " create <name> (letters, numbers, _ and - only)",
                            NamedTextColor.YELLOW);
                    return true;
                }
                Location a = this.pos1.get(player.getUniqueId());
                Location b = this.pos2.get(player.getUniqueId());
                if (a == null || b == null || a.getWorld() == null || !a.getWorld().equals(b.getWorld())) {
                    this.msg(sender, "Set pos1 and pos2 first (same world).", NamedTextColor.RED);
                    return true;
                }
                String key = args[1].toLowerCase(Locale.ROOT);
                if (this.zones.containsKey(key)) {
                    this.msg(sender, "A zone with that name already exists.", NamedTextColor.RED);
                    return true;
                }
                this.zones.put(key, new Zone(args[1], a.getWorld().getName(),
                        a.getBlockX(), a.getBlockY(), a.getBlockZ(), b.getBlockX(), b.getBlockY(), b.getBlockZ()));
                this.zonesVersion++;
                this.save();
                this.msg(sender, "Zone '" + args[1] + "' created.", NamedTextColor.GREEN);
            }
            case "remove" -> {
                if (args.length < 2) {
                    this.msg(sender, "Usage: /" + label + " remove <name>", NamedTextColor.YELLOW);
                    return true;
                }
                Zone removed = this.zones.remove(args[1].toLowerCase(Locale.ROOT));
                if (removed == null) {
                    this.msg(sender, "No such zone.", NamedTextColor.RED);
                    return true;
                }
                this.zonesVersion++;
                this.save();
                this.msg(sender, "Zone '" + removed.name + "' removed.", NamedTextColor.GREEN);
            }
            case "list" -> {
                if (this.zones.isEmpty()) {
                    this.msg(sender, "No zones.", NamedTextColor.YELLOW);
                    return true;
                }
                for (Zone zone : this.zones.values()) {
                    this.msg(sender, zone.name + " (" + zone.world + ") " + zone.minX + "," + zone.minY + ","
                            + zone.minZ + " -> " + zone.maxX + "," + zone.maxY + "," + zone.maxZ, NamedTextColor.GRAY);
                }
            }
            case "reload" -> {
                this.reload();
                this.msg(sender, "Reloaded.", NamedTextColor.GREEN);
            }
            default -> this.msg(sender, "Usage: /" + label + " <pos1|pos2|create|remove|list|reload>",
                    NamedTextColor.YELLOW);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission("starkcompat.admin")) {
            return out;
        }
        if (args.length == 1) {
            for (String s : List.of("pos1", "pos2", "create", "remove", "list", "reload")) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) {
                    out.add(s);
                }
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("remove")) {
            for (Zone zone : this.zones.values()) {
                if (zone.name.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) {
                    out.add(zone.name);
                }
            }
        }
        return out;
    }
}
